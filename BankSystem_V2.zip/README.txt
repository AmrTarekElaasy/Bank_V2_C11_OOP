===========================================
💰 Bank_V2_C11_OOP - Bank Management System
===========================================

A fully integrated banking system developed in C++ using Object-Oriented Programming (OOP), containing all core functionalities for managing customers, managers, financial operations, and currency exchange.

-------------------------------------------
🔐 Login Credentials
-------------------------------------------
Main Administrator:
- Username: Admin
- Password: Admin

⚠️ NOTE: If the password is entered incorrectly 3 consecutive times, the system will shut down automatically.

-------------------------------------------
🌟 System Features
-------------------------------------------

✅ Customer Management:
- View customer list
- Add new customer
- Delete customer
- Update customer data
- Search for a customer

💰 Financial Operations:
- Deposit funds
- Withdraw funds
- Transfer funds between accounts

👥 Manager Management:
- View manager list
- Add new manager
- Delete manager
- Update manager data (including editing permissions)
- Search for a manager

💱 Currency Exchange:
- View available currencies
- Search for a specific currency
- Update exchange rates
- Currency calculator between any two currencies

🧾 Log Management:
- Transfer Log: Each transfer is saved in an encrypted file
- Login Log: All login attempts are saved in an encrypted file
- Error Log: System errors saved in "ErrorFile.log"
- Dedicated Screens to view transfer and login history

-------------------------------------------
🔒 Security System
-------------------------------------------
- Customer data is encrypted
- Manager data is encrypted in the "Users" file
- All logs are stored in encrypted files
- No manager can view or edit Admin data
- Permission-based manager access
- Decryption handled temporarily within the system UI

-------------------------------------------
📋 System Constraints
-------------------------------------------
- Admin cannot be deleted
- Admin data editable only by Admin
- Managers need active permission to log in

-------------------------------------------
📄 License
-------------------------------------------
This project is licensed under the MIT License

-------------------------------------------
👨‍💻 Developed by: Amr Tarek Elaasy
GitHub: https://github.com/AmrTarekElaasy
-------------------------------------------
